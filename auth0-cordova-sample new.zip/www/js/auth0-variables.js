var AUTH0_CLIENT_ID='tKlX99Abu3Qt7lXiSiTlMbchGMI2YwJ0'; 
var AUTH0_DOMAIN='wtv.auth0.com'; 
var AUTH0_CALLBACK_URL=location.href;